const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const multer = require('multer');
const cloudinary = require('cloudinary').v2;

const app = express();
const PORT = process.env.PORT || 6500;

// Middleware
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect('mongodb+srv://kiran:TxHospitals@cluster0.5gqkfgc.mongodb.net/?retryWrites=true&w=majority',
  {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then((res) => {
    console.log("Database connected");
  })
  .catch((err) => {
    console.log(`Database connection error: ${err}`);
  });

// Product model
const Product = mongoose.model('Product', {
  name: String,
  description: String,
  price: Number,
  image: String, // Store the image path in the database
});

const storage = multer.diskStorage({
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
});

// upload image
const upload = multer({ storage: storage });
cloudinary.config({
  cloud_name: "dcxcyqmtu",
  api_key: "891444179858785",
  api_secret: "PVsWzlY1r_nRaZn-QDu23ag-VwI"
});

// Routes
// post a product with image
app.post('/api/products', upload.single('image'), async (req, res) => {
  try {
    // Access the Cloudinary URL from the request object
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    const data = req.file?.path;

    // Upload image to Cloudinary
    const result = await cloudinary.uploader.upload(data);
    req.cloudinaryUrl = result.url; // Store the Cloudinary URL in the request object
    const cloudinaryUrl = req.cloudinaryUrl;

    // Create a new Product instance and save it to the database
    const newProduct = new Product({
      name: 'Product 3',
      description: 'This is a product',
      price: 19.99,
      image: cloudinaryUrl,
    });
    await newProduct.save(); // Save the product to the database
    // Send a success response with the Cloudinary URL
    return res.status(200).json({
      ok: true,
      message: "File uploaded successfully"
    });
  } catch (err) {
    console.log(err, "err");
    return res.status(500).json({
      ok: false,
      message: "Something went wrong"
    });
  }
});
// Get a product with image
app.get('/api/products', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// // Delete a product with image
app.delete('/api/products/:id', upload.single('image'), async (req, res) => {
  const id = req.params.id;

  try {
    const product = await Product.findOne({ _id: id });
    if (!product) {
      res.status(404).json({ message: 'Product not found' });
      return;
    }

    const imagePath = product.image;
    if (imagePath) {
      await fs.unlinkSync(imagePath); // Delete the image file
    }

    await Product.deleteOne({ _id: id });
    res.status(200).json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Failed to delete product:', error);
    res.status(500).json({ message: 'An error occurred' });
  }
});

// // Update a product with image
app.put('/api/products/:id', upload.single('image'), async (req, res) => {
  const id = req.params.id; // Extract product ID from request params
  try {
    const product = await Product.findOne({ _id: id }); // Fetch the product with the specified ID
    if (!product) { // Check if the product exists
      return res.status(404).json({ message: 'Product not found' });
    }
    const updatedProductData = req.body; // Extract updated product data from request body
    const oldImageURL = product.image; // Retrieve the old image URL
    // Handle image upload if provided
    if (req.file) {
      const imagePath = req.file.path; // Get the path of the uploaded image
      const newImageURL = await cloudinary.uploader.upload(imagePath); // Upload image to Cloudinary
      updatedProductData.image = newImageURL; // Update image URL in product data
      // Delete the old image file if it exists
      if (oldImageURL) {
        await fs.unlinkSync(oldImageURL);
      }
    }
    // Update product record in the database
    await Product.updateOne({ _id: id }, { $set: updatedProductData });
    res.status(200).json({ message: 'Product updated successfully' }); 
  } catch (error) {
    console.error('Failed to update product:', error); 
    res.status(500).json({ message: 'An error occurred' }); 
  }
});
// Start the server
app.listen(PORT, () => {
  console.log(`Product API is running on http://localhost:${PORT}`);
});
